{{- /*
Returns the value for volumes
*/ -}}
{{- define "stack.lib.pod.field.volumes" -}}
  {{- $rootContext := .ctx.rootContext -}}

  {{- /* Default to empty list */ -}}
  {{- $persistenceItemsToProcess := dict -}}
  {{- $volumes := list -}}

  {{- /* Loop over persistence values */ -}}
  {{- range $identifier, $persistenceValues := $rootContext.Values.persistence -}}
    {{- /* Enable persistence item by default, but allow override */ -}}
    {{- $persistenceEnabled := true -}}
    {{- if hasKey $persistenceValues "enabled" -}}
      {{- $persistenceEnabled = $persistenceValues.enabled -}}
    {{- end -}}

    {{- if $persistenceEnabled -}}
      {{- $_ := set $persistenceItemsToProcess $identifier $persistenceValues -}}
    {{- end -}}
  {{- end -}}

  {{- /* Loop over persistence items */ -}}
  {{- range $identifier, $persistenceValues := $persistenceItemsToProcess -}}
    {{- $volume := dict "name" $identifier -}}

    {{- /* PVC persistence type */ -}}
    {{- if eq (default "persistentVolumeClaim" $persistenceValues.type) "persistentVolumeClaim" -}}
      {{- $pvcName := (include "stack.lib.chart.names.fullname" $rootContext) -}}
      {{- if $persistenceValues.existingClaim -}}
        {{- /* Always prefer an existingClaim if that is set */ -}}
        {{- $pvcName = include "stack.lib.common.renderString" (dict "value" $persistenceValues.existingClaim "rootContext" $rootContext) -}}
      {{- else -}}
        {{- /* Otherwise refer to the PVC name */ -}}
        {{- $object := (include "stack.lib.pvc.getByIdentifier" (dict "rootContext" $rootContext "id" $identifier) | fromYaml) -}}
        {{- $pvcName = get $object "name" -}}
      {{- end -}}
      {{- $_ := set $volume "persistentVolumeClaim" (dict "claimName" $pvcName) -}}

    {{- /* configMap persistence type */ -}}
    {{- else if eq $persistenceValues.type "configMap" -}}
      {{- $objectName := "" -}}
      {{- if $persistenceValues.name -}}
        {{- $objectName = include "stack.lib.common.renderString" (dict "value" $persistenceValues.name "rootContext" $rootContext) -}}
      {{- else if $persistenceValues.identifier -}}
        {{- $object := (include "stack.lib.configMap.getByIdentifier" (dict "rootContext" $rootContext "id" $persistenceValues.identifier) | fromYaml ) -}}
        {{- if not $object -}}
          {{- fail (printf "Persistence '%s': No ConfigMap found with identifier '%s'. Ensure a ConfigMap with this identifier exists and is enabled under 'configMaps.%s'." $identifier $persistenceValues.identifier $persistenceValues.identifier) -}}
        {{- end -}}
        {{- $objectName = $object.name -}}
      {{- end -}}
      {{- $_ := set $volume "configMap" dict -}}
      {{- $_ := set $volume.configMap "name" $objectName -}}
      {{- with $persistenceValues.defaultMode -}}
        {{- $_ := set $volume.configMap "defaultMode" . -}}
      {{- end -}}
      {{- with $persistenceValues.items -}}
        {{- $_ := set $volume.configMap "items" . -}}
      {{- end -}}

    {{- /* Secret persistence type */ -}}
    {{- else if eq $persistenceValues.type "secret" -}}
      {{- $objectName := "" -}}
      {{- if $persistenceValues.name -}}
        {{- $objectName = include "stack.lib.common.renderString" (dict "value" $persistenceValues.name "rootContext" $rootContext) -}}
      {{- else if $persistenceValues.identifier -}}
        {{- $object := (include "stack.lib.secret.getByIdentifier" (dict "rootContext" $rootContext "id" $persistenceValues.identifier) | fromYaml ) -}}
        {{- if not $object -}}
          {{- fail (printf "Persistence '%s': No Secret found with identifier '%s'. Ensure a Secret with this identifier exists and is enabled under 'secrets.%s'." $identifier $persistenceValues.identifier $persistenceValues.identifier) -}}
        {{- end -}}
        {{- $objectName = $object.name -}}
      {{- else if $persistenceValues.externalSecretRef -}}
        {{- $object := (include "stack.lib.externalSecret.getByIdentifier" (dict "rootContext" $rootContext "id" $persistenceValues.externalSecretRef) | fromYaml ) -}}
        {{- if not $object -}}
          {{- fail (printf "Persistence '%s': No ExternalSecret found with identifier '%s'. Ensure an ExternalSecret with this identifier exists and is enabled under 'externalSecrets.%s'." $identifier $persistenceValues.externalSecretRef $persistenceValues.externalSecretRef) -}}
        {{- end -}}
        {{- $objectName = include "stack.lib.externalSecret.getSecretName" $object -}}
      {{- end -}}
      {{- $_ := set $volume "secret" dict -}}
      {{- $_ := set $volume.secret "secretName" $objectName -}}
      {{- with $persistenceValues.defaultMode -}}
        {{- $_ := set $volume.secret "defaultMode" . -}}
      {{- end -}}
      {{- with $persistenceValues.items -}}
        {{- $_ := set $volume.secret "items" . -}}
      {{- end -}}

    {{- /* emptyDir persistence type */ -}}
    {{- else if eq $persistenceValues.type "emptyDir" -}}
      {{- $_ := set $volume "emptyDir" dict -}}
      {{- with $persistenceValues.medium -}}
        {{- $_ := set $volume.emptyDir "medium" . -}}
      {{- end -}}
      {{- with $persistenceValues.sizeLimit -}}
        {{- $_ := set $volume.emptyDir "sizeLimit" . -}}
      {{- end -}}

    {{- /* ephemeral persistence type */ -}}
    {{- else if eq $persistenceValues.type "ephemeral" -}}
      {{- $_ := set $volume "ephemeral" dict -}}
      {{- $vct := dict -}}
      {{- $_ := set $vct "spec" dict -}}
      {{- with $persistenceValues.accessMode -}}
        {{- $_ := set $vct.spec "accessModes" (list .) -}}
      {{- end -}}
      {{- with $persistenceValues.storageClass -}}
        {{- $_ := set $vct.spec "storageClassName" . -}}
      {{- end -}}
      {{- with $persistenceValues.size -}}
        {{- $_ := set $vct.spec "resources" (dict "requests" (dict "storage" .)) -}}
      {{- end -}}
      {{- $_ := set $volume.ephemeral "volumeClaimTemplate" $vct -}}

    {{- /* hostPath persistence type */ -}}
    {{- else if eq $persistenceValues.type "hostPath" -}}
      {{- $_ := set $volume "hostPath" dict -}}
      {{- $_ := set $volume.hostPath "path" (required "hostPath not set" $persistenceValues.hostPath) -}}
      {{- with $persistenceValues.hostPathType }}
        {{- $_ := set $volume.hostPath "type" . -}}
      {{- end -}}

    {{- /* image persistence type */ -}}
    {{- else if and (ge ($rootContext.Capabilities.KubeVersion.Minor | int) 33) (eq $persistenceValues.type "image") -}}
      {{- $_ := set $volume "image" dict -}}
      {{- if kindIs "string" $persistenceValues.image -}}
        {{- $_ := set $volume.image "reference" $persistenceValues.image -}}
      {{- else -}}
        {{- $_ := set $volume.image "reference" (include "stack.lib.imageSpecificationToImage" (dict "rootContext" $rootContext "imageSpec" $persistenceValues.image)) -}}
      {{- end -}}
      {{- with $persistenceValues.pullPolicy -}}
        {{- $_ := set $volume.image "pullPolicy" . -}}
      {{- end -}}

    {{- /* nfs persistence type */ -}}
    {{- else if eq $persistenceValues.type "nfs" -}}
      {{- $_ := set $volume "nfs" dict -}}
      {{- $_ := set $volume.nfs "server" (required "server not set" $persistenceValues.server) -}}
      {{- $_ := set $volume.nfs "path" (required "path not set" $persistenceValues.path) -}}

    {{- /* projected persistence type */ -}}
    {{- else if eq $persistenceValues.type "projected" -}}
      {{- $_ := set $volume "projected" dict -}}
      {{- $sources := required (printf "Persistence '%s': Projected volume sources are required. Specify 'persistence.%s.sources' with at least one source." $identifier $identifier) $persistenceValues.sources -}}
      {{- $_ := set $volume.projected "sources" (include "stack.lib.common.renderString" (dict "value" (toYaml $sources) "rootContext" $rootContext) | fromYamlArray) -}}
      {{- with $persistenceValues.defaultMode -}}
        {{- $_ := set $volume.projected "defaultMode" . -}}
      {{- end -}}

    {{- /* custom persistence type */ -}}
    {{- else if eq $persistenceValues.type "custom" -}}
      {{- $volume = $persistenceValues.volumeSpec -}}
      {{- $_ := set $volume "name" $identifier -}}

    {{- /* Fail otherwise */ -}}
    {{- else -}}
      {{- fail (printf "Not a valid persistence.type (%s)" $persistenceValues.type) -}}
    {{- end -}}

    {{- $volumes = append $volumes $volume -}}
  {{- end -}}

  {{- if not (empty $volumes) -}}
    {{- $volumes | toYaml -}}
  {{- end -}}
{{- end -}}
